Minecraft Java edition 1.8.8 playable on Chromebook, Mac, and Windows.

This was made possible thanks to lax1dude and ayunami2000.
